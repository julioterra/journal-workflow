---
type: Organization
title: Stanford University
---

# Stanford University

A private research university in Stanford, California.
