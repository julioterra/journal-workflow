---
type: Book
title: Thinking Fast and Slow
---

# Thinking Fast and Slow

A book by Daniel Kahneman about decision-making and cognitive biases.
