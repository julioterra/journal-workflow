---
type: Project
title: Journal Workflow
---

# Journal Workflow

A Pandoc + LaTeX workflow for converting Capacities journal exports to print-ready PDFs.
