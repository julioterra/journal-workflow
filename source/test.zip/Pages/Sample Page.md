---
type: Page
title: Sample Page
---

# Sample Page

This is a sample page to test the remove-object-embeds filter.

When this page is embedded as a standalone link, it should be removed from the final PDF.
When referenced inline, it should remain as a link.
