---
type: Person
title: David Chen
---

# David Chen

A test person entry for verifying the name recognition and indexing system.
