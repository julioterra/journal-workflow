---
type: PDF
title: media-types-guide
description: Guide to media types in printed journals
icon: null
createdAt: '2024-11-15T00:00:00.000Z'
creationDate: 2024-11-15 00:00
modificationDate: 2024-11-15 00:00
tags: []
previewImage: null
source: upload
url: null
numberOfPages: 1
fileSize: 2600
tableOfContents: false
mimeType: application/pdf
---


Media: ![PDF](PDFs/Media/media-types-guide.pdf)
