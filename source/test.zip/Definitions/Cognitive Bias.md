---
type: Definition
title: Cognitive Bias
---

# Cognitive Bias

A systematic pattern of deviation from norm or rationality in judgment.
