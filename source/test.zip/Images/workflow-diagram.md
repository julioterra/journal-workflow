---
type: Image
title: workflow-diagram
description: Journal Workflow Pipeline Diagram
createdAt: '2024-11-15T00:00:00.000Z'
creationDate: 2024-11-15 00:00
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 1600000
width: 1200
height: 800
---


Media: ![Image](Images/Media/workflow-diagram.png)
